﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using TuioDemo;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

//using System.Diagnostics.Metrics;


namespace TuioDemo
{
    public class Connect
    {
        int byteCount;
        NetworkStream stream;
        byte[] sendData;
        TcpClient tcpClient;

        public bool connectToSocket(String host, int portNumber)
        {
            try
            {
                tcpClient = new TcpClient(host, portNumber);
                MessageBox.Show("Connection Made ! with " + host);
                return true;
            }
            catch (SocketException e)
            {
                MessageBox.Show("Connection Failed: " + e);
                return false;
            }
        }

        public bool sendMessage(String msg)
        {
            try
            {
                byteCount = Encoding.ASCII.GetByteCount(msg);
                sendData = new byte[byteCount];
                sendData = Encoding.ASCII.GetBytes(msg);
                stream = tcpClient.GetStream();
                stream.Write(sendData, 0, sendData.Length);
                MessageBox.Show("Data sent" + msg);
                return true;
            }
            catch (System.NullReferenceException e)
            {
                MessageBox.Show("Connection not initialized : " + e);
                return false;
            }
        }

        public string recieveMessage()
        {
            try
            {
                // Receive some data from the peer.
                stream = tcpClient.GetStream();
                byte[] receiveBuffer = new byte[1024];
                int bytesReceived = stream.Read(receiveBuffer, 0, receiveBuffer.Length);
                string data = Encoding.UTF8.GetString(receiveBuffer, 0, receiveBuffer.Length);

                //MessageBox.Show($"This is what the peer sent to you: {data}");

                return data;
                //stream = tcpClient.GetStream();
                //var ms =stream.Read;

            }
            catch (Exception e)
            {
                MessageBox.Show("Connection not initialized : " + e);
                return null;
            }
        }
        public bool closeConnection()
        {
            stream.Close();
            tcpClient.Close();
            MessageBox.Show("Connection terminated : ");
            return true;
        }

        /* static void Main()
         {
             ClientC c = new ClientC();
             c.connectToSocket("0.0.0.0", 5000);
             c.sendMessage("hello from C#");
             c.recieveMessage();
             c.closeConnection();

         }*/
    }
}