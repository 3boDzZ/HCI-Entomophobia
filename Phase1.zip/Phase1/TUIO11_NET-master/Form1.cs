﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuioDemo
{
    public partial class Form1 : Form
    {
        List<cockroach> L = new List<cockroach>();
        Timer tt = new Timer();
        int ctt = 0, score = 1;
        Bitmap off;
        Connect c = new Connect();
        string data;
        string[] accepted;
        float rx, ry, lx, ly;
        string handtype;
        public Form1()
        {
            WindowState = FormWindowState.Maximized;
            this.Load += Form1_Load;
            this.Paint += Form1_Paint;
            tt.Tick += Tt_Tick;
            tt.Start();
            MouseClick += Form1_MouseClick;
            MouseMove += Form1_MouseMove;
            InitializeComponent();
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {

        }
        void kill(string data)
        {
            this.Text = data;
            if (data == "Right" || data == "Left")
            {
                int x = 0;
                while (x < L.Count)
                {

                    if (L[x].y < 0)
                    {
                        x++;
                    }
                    else
                    {
                        L.RemoveAt(x);
                        break;
                    }

                }
            }
        }
        /*void kill(float rx, float ry,float lx,float ly)//////////////bugg
        {
            for (int i = 0; i < L.Count; i++)
            {
                if ((rx>L[i].x&&rx<=L[i].x+L[i].bug.Width&& ry > L[i].y && ry <= L[i].y + L[i].bug.Height)||(lx > L[i].x && lx <= L[i].x + L[i].bug.Width && ly > L[i].y && ly <= L[i].y + L[i].bug.Height))
                {
                    L.RemoveAt(i);
                    score++;
                    DrawDubble(this.CreateGraphics());

                }
            }

        }*/
        string[] send;
        private void Tt_Tick(object sender, EventArgs e)
        {
            data = c.recieveMessage();
            // accepted = data.Split(',');
            //handtype = accepted[0];
            // rx = float.Parse(accepted[1]) * this.Width;
            //ry = float.Parse(accepted[2]) * this.Height;
            send = data.Split(',');
            // lx = float.Parse(accepted[3]) * this.Width;
            //ly = float.Parse(accepted[4])*this.Height;
            //kill(rx, ry, lx, ly);
            kill(send[0]);
            if (ctt % 7 == 0)
            {
                cockroach pnn = new cockroach();
                pnn.bug = new Bitmap("bug.bmp");
                pnn.bug.MakeTransparent(pnn.bug.GetPixel(0, 0));
                pnn.bug.MakeTransparent(Color.White);
                Random rr = new Random();
                int v = rr.Next(10, this.ClientSize.Width);

                pnn.x = v;
                pnn.y = this.ClientSize.Height;
                L.Add(pnn);
            }
            for (int i = 0; i < L.Count; i++)
            {
                L[i].y -= 10;
            }
            if (ctt % 2 == 0)
            {
                for (int i = 0; i < L.Count; i++)
                {
                    L[i].x -= 5;
                }
            }
            else
            {
                for (int i = 0; i < L.Count; i++)
                {
                    L[i].x += 5;
                }
            }
            ctt++;
            DrawDubble(this.CreateGraphics());
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            DrawDubble(e.Graphics);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            off = new Bitmap(this.ClientSize.Width, this.ClientSize.Height);

            c.connectToSocket("localhost", 5001);
            //c.sendMessage(" hello from C#");
            //c.closeConnection();
        }
        void DrawScene(Graphics g)
        {
            g.Clear(Color.White);
            for (int i = 0; i < L.Count; i++)
            {
                g.DrawImage(L[i].bug, L[i].x, L[i].y, 50, 50);
            }
        }
        void DrawDubble(Graphics g)
        {
            Graphics g2 = Graphics.FromImage(off);
            DrawScene(g2);
            g.DrawImage(off, 0, 0);
        }
    }
}
