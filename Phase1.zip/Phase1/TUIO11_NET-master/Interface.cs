﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TuioDemo
{

    public partial class Interface : Form
    {
        Connect c = new Connect();
        Form1 f1;
        public int flagID = 0;
        public Interface()
        {
            InitializeComponent();
        }
        string data;
        string[] send;
        public static int flagg = 0;
        
        private void Interface_Load(object sender, EventArgs e)
        {
            //c.connectToSocket("localhost", 65434);


        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Text = "Connecting...";
           // c.connectToSocket("localhost", 65434);
           // c.sendMessage("true");
            c = new Connect();
            label1.Text = "Please Wait...";
            c.connectToSocket("localhost", 5000);
            this.Text = "Connected";
            data = c.recieveMessage();
            send = data.Split(',');
            this.Text = send[0];
            if (send[0] == "..")
            {
                MessageBox.Show("Welcome: " + send[0] + " Press OK to Start");
                MessageBox.Show("Please use marker ID 7 to play");
                flagID = 7;

                // f1 = new Form1();
                //f1.Show();
                //this.Hide();
                TuioDemo app = new TuioDemo(flagg,flagID);
                app.Show();
                this.Hide();
                //  c.closeConnection();
            }
            if (send[0] == "JDA-068")
            {
                MessageBox.Show("Welcome: " + send[0] + " Press OK to Start");
                MessageBox.Show("Please use marker ID 8 to play");
                flagID = 8;
                // f1 = new Form1();
                //f1.Show();
                //this.Hide();
                TuioDemo app = new TuioDemo(flagg, flagID);
                app.Show();
                this.Hide();
                //c.closeConnection();

            }
            if (send[0] == ".")
            {
                MessageBox.Show("Welcome: " + send[0] + " Press OK to Start");
                MessageBox.Show("Please use marker ID 9 to play");
                flagID = 9;
                // f1 = new Form1();
                //f1.Show();
                //this.Hide();
                TuioDemo app = new TuioDemo(flagg, flagID);
                app.Show();
                this.Hide();
               // c.closeConnection();

            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        public static void Main(string[] argv)
        {
            int port = 0;
            switch (argv.Length)
            {
                case 1:
                    port = int.Parse(argv[0], null);
                    if (port == 0) goto default;
                    break;
                case 0:
                    port = 3333;
                    break;
                default:
                    Console.WriteLine("usage: mono TuioDemo [port]");
                    Environment.Exit(0);
                    break;
            }
            flagg = port;
            //TuioDemo app = new TuioDemo(port,flagg);
            Application.Run(new Interface());

            
        }
    }

}

