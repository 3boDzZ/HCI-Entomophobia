﻿using System.Drawing;

namespace TuioDemo
{
    public class cockroach
    {
        public int x, y;
        public Bitmap bug;
    }
}