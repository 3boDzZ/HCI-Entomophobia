﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HCI
{
    public partial class Form1 : Form
    {
        Connect c = new Connect();
        public int flagID = 0;
        string data;
        string[] send;
        Timer tt = new Timer();
        Bitmap off; 
        string[] type;

        string datafear;
        string ad;
        int flagfear = 0;
       
        Font font = new Font("Arial", 20.0f);
        SolidBrush fntBrush = new SolidBrush(Color.Black);
        cockroach cock = new cockroach();
        int sx = 550, sy = 10;
        public static int flagg = 0;
        int xc, yc;
        string[] co;
        int drawS = 0;
        int flagEye = 0;
        Random rand = new Random();
        int ctt = 0;
        int flagWelcome = 0;
        int bigFlag = 0;
        public Form1()
        {
            InitializeComponent();
            this.Paint += Form1_Paint;
            this.Load += Form1_Load;
            tt.Tick += Tt_Tick;
            tt.Start();
        }

        private void Tt_Tick(object sender, EventArgs e)
        {
            if (bigFlag == 1)
            {
                if (ctt % 10 == 0)
                {
                    sx = rand.Next(0, 1200);
                    sy = rand.Next(0, 500);
                }
                string filePathFlag = @"D:\Abdelrahman\SEM8\CS484\HCI\HCI\bin\Debug\flag.txt";

                try
                {
                    //datafear = c.recieveMessage();
                    //typefear = datafear.Split(',');
                    //fear = Convert.ToInt32(typefear[0]);
                    //normal = Convert.ToInt32(typefear[1]);
                    //c.closeConnection();
                    //c = new Connect();

                    using (StreamReader sr = new StreamReader(filePathFlag))
                    {
                        // Read the entire file and store it as a string
                        string fileContents = sr.ReadToEnd();
                        flagfear = Convert.ToInt32(fileContents);

                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("An exception occurred in fear: " + ex.Message);
                }
                //if (flagWelcome == 0)
                {
                    string filePath = @"D:\Abdelrahman\SEM8\CS484\HCI\HCI\bin\Debug\track.txt";

                    try
                    {
                        //drawS = 0;
                        // Open the file using a StreamReader
                        using (StreamReader sr = new StreamReader(filePath))
                        {
                            // Read the entire file and store it as a string
                            string fileContents = sr.ReadToEnd();
                            co = fileContents.Split(',');
                            xc = Convert.ToInt32(co[0]);
                            yc = Convert.ToInt32(co[1]);
                            drawS = 1;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("The file could not be read:");
                        Console.WriteLine(ex.Message);
                    }
                    flagWelcome++;
                }
                string filePathEye = @"D:\Abdelrahman\SEM8\CS484\HCI\HCI\bin\Debug\eye.txt";

                try
                {
                    //drawS = 0;
                    // Open the file using a StreamReader
                    using (StreamReader sr = new StreamReader(filePathEye))
                    {
                        // Read the entire file and store it as a string
                        string fileContents = sr.ReadToEnd();
                        flagEye = Convert.ToInt32(fileContents);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("The file could not be read:");
                    Console.WriteLine(ex.Message);
                }
            }
            string filePathID = @"D:\Abdelrahman\SEM8\CS484\HCI\HCI\bin\Debug\faceID.txt";

            try
            {
                //drawS = 0;
                // Open the file using a StreamReader
                using (StreamReader sr = new StreamReader(filePathID))
                {
                    // Read the entire file and store it as a string
                    string fileContents = sr.ReadToEnd();
                    this.Text = fileContents;
                    bigFlag = 1;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("The file could not be read:");
                Console.WriteLine(ex.Message);
            }
            ctt++;
            DrawDubb(this.CreateGraphics());
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            DrawDubb(this.CreateGraphics());
        }
      
        private void Form1_Load(object sender, EventArgs e)
        {
            off = new Bitmap(ClientSize.Width, ClientSize.Height);
            c.connectToSocket("localhost", 5000);

        }
        Bitmap imgs;

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            button1.Visible = false;
            button2.Visible = false;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            tt.Start();
            flagfear = 0;
            flagEye = 0;
            button2.Visible = false;
            button1.Visible = false;

        }

        void DrawScene(Graphics g)
        {
            if (bigFlag == 1)
            {
                g.Clear(Color.White);
                cock.bug = new Bitmap("bug.bmp");
                cock.bug.MakeTransparent(Color.White);
                cock.bug.MakeTransparent(cock.bug.GetPixel(0, 0));
                g.DrawImage(cock.bug, sx, sy, 100, 100);
                imgs = new Bitmap("spraay2.bmp");
                if (flagfear == 1)
                {
                    g.Clear(Color.White);
                    g.DrawString("Please take a rest", font, fntBrush, new PointF(100, 100));
                    tt.Stop();
                    button2.Visible = true;
                    button1.Visible = true;

                }
                if (flagEye == 1)
                {
                    g.Clear(Color.White);
                    g.DrawString("Are you okay? ", font, fntBrush, new PointF(300, 300));
                    tt.Stop();
                    button2.Visible = true;
                    button1.Visible = true;
                }
                if (drawS == 1)
                {
                    cock.bug = new Bitmap("bug.bmp");
                    cock.bug.MakeTransparent(Color.White);
                    cock.bug.MakeTransparent(cock.bug.GetPixel(0, 0));
                    g.DrawImage(cock.bug, sx, sy, 100, 100);
                    // float rotation = tobj.getAngleDegrees(-sx/2, -sy/2)%360;
                    //g.TranslateTransform(imgs.Width / 2, imgs.Height / 2);
                    //g.RotateTransform(rotation);
                    //g.TranslateTransform(-imgs.Width / 2, -imgs.Height / 2);
                    imgs.MakeTransparent(Color.White);
                    imgs.MakeTransparent(imgs.GetPixel(0, 0));
                    g.DrawImage(imgs, xc - 50, yc - 50, 70, 100);
                    //g.DrawImage(img, sx, sy, 100, 100);
                    //drawS = 0;
                }
                if (xc >= sx && xc < sx + 100 && yc >= sy && yc < sy + 100)
                {
                    //MessageBox.Show("Restart with mediapipe");
                    g.DrawString("Congratulations...\nIf you need to restart press continue", font, fntBrush, new PointF(500, 100));
                    tt.Stop();
                    button2.Visible = true;
                    button1.Visible = true;
                }
            }
        }
        void DrawDubb(Graphics g)
        {
            Graphics g2 = Graphics.FromImage(off);
            DrawScene(g2);
            g.DrawImage(off, 0, 0);
        }
    }
}
