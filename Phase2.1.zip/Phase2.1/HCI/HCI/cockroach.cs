﻿using System.Drawing;

namespace HCI
{
    public class cockroach
    {
        public int x, y;
        public Bitmap bug;
    }
}